import * as React from "react"

export function ThemeProvider({ children }) {
  return <>{children}</>
}
